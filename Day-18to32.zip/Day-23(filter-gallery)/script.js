const fliterBtns = document.querySelectorAll('#fliterBtns');
const img = document.querySelectorAll("#img");
fliterBtns.forEach((Fbtn)=>{
    Fbtn.addEventListener('click',(e)=>{
        
        fliterBtns.forEach((butt)=>{
            butt.classList.remove('active');
        });
        const FilterB = e.target.dataset.filter;
        img.forEach((IMGL)=>{
            if(FilterB == "all"){
                IMGL.style.display="block";
            }else{
                const FilterI = IMGL.dataset.item;
                if(FilterB == FilterI){
                    IMGL.style.display="block";
                }else{
                    IMGL.style.display="none";
                }
            }
        });
        
        //console.log(FilterB)
        Fbtn.classList.add('active');
    });
});




const searchImg = () =>{
    // console.log("hello");
    // console.log(srhImg.length);
   
    const srhImg = document.querySelectorAll("#img");
    
    for(let i=0;i<srhImg.length;i++){
        // console.log(InputT);
        let searchFilter = srhImg[i].dataset.item;
        const InputT = document.getElementById('inputsearch').value;
        // console.log(srhImg[i])
        // console.log(searchFilter)
        // console.log(InputT)
        if(InputT.toUpperCase().includes(searchFilter.toUpperCase())){
            srhImg[i].style.display = "block";
        }else{
            srhImg[i].style.display = "none";
        }
    }

}




