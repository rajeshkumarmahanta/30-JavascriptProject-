// for first name
const fnameInput = document.querySelector("#fnameInput");
fnameInput.addEventListener("click", () => {
  const lblfname = document.querySelector("#lblfname");
  lblfname.style.transform = "translateY(-28px)";
  lblfname.style.transition = "0.3s";
  lblfname.style.color = "black";
});
fnameInput.addEventListener("keydown", () => {
  const lblfname = document.querySelector("#lblfname");
  lblfname.style.transform = "translateY(-28px)";
  lblfname.style.transition = "0.3s";
  lblfname.style.color = "black";
});
if (fnameInput.value != "") {
  let lblfname = document.querySelector("#lblfname");
  lblfname.style.transform = "translateY(-28px)";
}

// for last name
const lnameInput = document.querySelector("#lnameInput");
lnameInput.addEventListener("click", () => {
  const lbllname = document.querySelector("#lbllname");
  lbllname.style.transform = "translateY(-28px)";
  lbllname.style.transition = "0.3s";
  lbllname.style.color = "black";
});
lnameInput.addEventListener("keydown", () => {
  const lbllname = document.querySelector("#lbllname");
  lbllname.style.transform = "translateY(-28px)";
  lbllname.style.transition = "0.3s";
  lbllname.style.color = "black";
});
if (lnameInput.value != "") {
  let lbllname = document.querySelector("#lbllname");
  lbllname.style.transform = "translateY(-28px)";
}
// for mail
const mailInput = document.querySelector("#mailInput");
mailInput.addEventListener("click", () => {
  const lblmail = document.querySelector("#lblmail");
  lblmail.style.transform = "translateY(-28px)";
  lblmail.style.transition = "0.3s";
  lblmail.style.color = "black";
});
mailInput.addEventListener("keydown", () => {
  const lblmail = document.querySelector("#lblmail");
  lblmail.style.transform = "translateY(-28px)";
  lblmail.style.transition = "0.3s";
  lblmail.style.color = "black";
});
if (mailInput.value != "") {
  let lblmail = document.querySelector("#lblmail");
  lblmail.style.transform = "translateY(-28px)";
}
// for phone no
const phoneInput = document.querySelector("#phoneInput");
phoneInput.addEventListener("click", () => {
  const lblphoneno = document.querySelector("#lblphoneno");
  lblphoneno.style.transform = "translateY(-28px)";
  lblphoneno.style.transition = "0.3s";
  lblphoneno.style.color = "black";
});
phoneInput.addEventListener("keydown", () => {
  const lblphoneno = document.querySelector("#lblphoneno");
  lblphoneno.style.transform = "translateY(-28px)";
  lblphoneno.style.transition = "0.3s";
  lblphoneno.style.color = "black";
});
if (phoneInput.value != "") {
  let lblphoneno = document.querySelector("#lblphoneno");
  lblphoneno.style.transform = "translateY(-28px)";
}
// for password
const passwordInput = document.querySelector("#passwordInput");
passwordInput.addEventListener("click", () => {
  const lblpassword = document.querySelector("#lblpassword");
  lblpassword.style.transform = "translateY(-28px)";
  lblpassword.style.transition = "0.3s";
  lblpassword.style.color = "black";
});
passwordInput.addEventListener("keydown", () => {
  const lblpassword = document.querySelector("#lblpassword");
  lblpassword.style.transform = "translateY(-28px)";
  lblpassword.style.transition = "0.3s";
  lblpassword.style.color = "black";
});
if (passwordInput.value != "") {
  let lblpassword = document.querySelector("#lblpassword");
  lblpassword.style.transform = "translateY(-28px)";
}
// for confirm password
const cnPasswordInput = document.querySelector("#cnpasswordInput");
cnPasswordInput.addEventListener("click", () => {
  const lblcnpassword = document.querySelector("#lblcnpassword");
  lblcnpassword.style.transform = "translateY(-28px)";
  lblcnpassword.style.transition = "0.3s";
  lblcnpassword.style.color = "black";
});
cnPasswordInput.addEventListener("keydown", () => {
  const lblcnpassword = document.querySelector("#lblcnpassword");
  lblcnpassword.style.transform = "translateY(-28px)";
  lblcnpassword.style.transition = "0.3s";
  lblcnpassword.style.color = "black";
});
if (cnPasswordInput.value != "") {
  let lblcnpassword = document.querySelector("#lblcnpassword");
  lblcnpassword.style.transform = "translateY(-28px)";
}

// validation function
function validation() {
  // error msg and checkbox
  var frmErr = document.querySelector("#frmErr");
  var errMsgfname = document.querySelector(".errMsgfname");
  var errMsglname = document.querySelector(".errMsglname");
  var errMsgemail = document.querySelector(".errMsgemail");
  var errMsgphone = document.querySelector(".errMsgphone");
  var errMsgpassword = document.querySelector(".errMsgpassword");
  var errMsgcnpassword = document.querySelector(".errMsgcnpassword");
  var checkphone = document.querySelector("#checkphone");
  var checkLname = document.querySelector("#checkLname");
  var checkFname = document.querySelector("#checkFname");
  var checkmail = document.querySelector("#checkmail");
  var checkpassword = document.querySelector("#checkpassword");
  var checkcnpassword = document.querySelector("#checkcnpassword");
  // //input boxes
  var inputBorderFname = document.querySelector("#fnameInput");
  var inputBorderLname = document.querySelector("#lnameInput");
  var inputBorderEmail = document.querySelector("#mailInput");
  var inputBorderPhone = document.querySelector("#phoneInput");
  var inputBorderPassword = document.querySelector("#passwordInput");
  var inputBorderCnPassword = document.querySelector("#cnpasswordInput");
  var validFname = document.querySelector("#fnameInput").value;
  var validLname = document.querySelector("#lnameInput").value;
  var validMail = document.querySelector("#mailInput").value;
  var validPhone = document.querySelector("#phoneInput").value;
  var validPassword = document.querySelector("#passwordInput").value;
  var validCnPassword = document.querySelector("#cnpasswordInput").value;


  var regxname = /^[A-Za-z]*$/; //for name regular expression
  // var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; // form mail regular expression
  var maildotPosition = validMail.lastIndexOf(".");
  var mailAtPosition = validMail.indexOf("@");
  //   first name validation
  if (validFname.length == 0 || validFname == "" || validFname == null) {
    checkFname.innerHTML = "";
    errMsgfname.innerHTML = `<i class="ri-error-warning-fill"></i> First name is required`;
    inputBorderFname.style.borderColor = "red";
    frmErr.innerHTML = "Please enter valid details";
    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);

    return false;
  } else if (!regxname.test(validFname)) {
    checkFname.innerHTML = "";
    errMsgfname.innerHTML = `<i class="ri-error-warning-fill"></i> Enter a valid name`;
    inputBorderFname.style.borderColor = "red";
    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);
    return false;
  } else {
    inputBorderFname.style.borderColor = "Green";
    errMsgfname.innerHTML = "";
    checkFname.innerHTML = `<i class="ri-checkbox-circle-line"></i>`;
  }

  //   last name validation
  if (validLname.length == 0 || validLname == "" || validLname == null) {
    checkLname.innerHTML = "";
    errMsglname.innerHTML = `<i class="ri-error-warning-fill"></i> Last name is required`;
    inputBorderLname.style.borderColor = "red";
    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);
    return false;
  } else if (!regxname.test(validLname)) {
    checkLname.innerHTML = "";
    errMsglname.innerHTML = `<i class="ri-error-warning-fill"></i> Enter a valid name`;
    inputBorderLname.style.borderColor = "red";
    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);
    return false;
  } else {
    errMsglname.innerHTML = "";
    inputBorderLname.style.borderColor = "green";
    checkLname.innerHTML = `<i class="ri-checkbox-circle-line"></i>`;
  }

  //   Email validation

  if (validMail.length == 0 || validMail == null || validMail == "") {
    checkmail.innerHTML = "";
    errMsgemail.innerHTML = `<i class="ri-error-warning-fill"></i> Please Enter email`;
    inputBorderEmail.style.borderColor = "red";
    frmErr.innerHTML = "Please enter valid details";
    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);

    return false;
  } else if (mailAtPosition < 1 || maildotPosition < mailAtPosition + 2 || maildotPosition + 2 >= validMail.length) {
    checkmail.innerHTML = "";
    errMsgemail.innerHTML = `<i class="ri-error-warning-fill"></i> Enter valid email`;
    inputBorderEmail.style.borderColor = "red";
    frmErr.innerHTML = "Please enter valid details";
    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);

    return false;
  } else {
    errMsgemail.innerHTML = "";
    inputBorderEmail.style.borderColor = "green";
    checkmail.innerHTML = `<i class="ri-checkbox-circle-line"></i>`;
  }

  //   phone validation

  if (validPhone.length == 0 || validPhone == null || validPhone == "") {
    checkphone.innerHTML = "";
    errMsgphone.innerHTML = `<i class="ri-error-warning-fill"></i> Please Enter Phone number`;
    inputBorderPhone.style.borderColor = "red";
    checkphone.innerHTML = "";
    frmErr.innerHTML = "Please enter valid details";
    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);

    return false;
  } else if (isNaN(validPhone)) {
    checkphone.innerHTML = "";
    errMsgphone.innerHTML = `<i class="ri-error-warning-fill"></i> Enter number only`;
    inputBorderPhone.style.borderColor = "red";
    frmErr.innerHTML = "Please enter valid details";

    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);

    return false;
  } else if (validPhone.length < 10) {
    checkphone.innerHTML = "";
    errMsgphone.innerHTML = `<i class="ri-error-warning-fill"></i> Phone number must be 10 digit`;
    inputBorderPhone.style.borderColor = "red";
    frmErr.innerHTML = "Please enter valid details";

    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);

    return false;
  } else if (validPhone.length > 10) {
    checkphone.innerHTML = "";
    errMsgphone.innerHTML = `<i class="ri-error-warning-fill"></i> enter valid phone number`;
    inputBorderPhone.style.borderColor = "red";
    frmErr.innerHTML = "Please enter valid details";

    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);

    return false;
  } else {
    errMsgphone.innerHTML = "";
    inputBorderPhone.style.borderColor = "green";
    checkphone.innerHTML = `<i class="ri-checkbox-circle-line"></i>`;
  }

  //   password validation
  if (
    validPassword.length == 0 ||
    validPassword == null ||
    validPassword == ""
  ) {
    checkpassword.innerHTML = "";
    errMsgpassword.innerHTML = `<i class="ri-error-warning-fill"></i> Enter Password`;
    inputBorderPassword.style.borderColor = "red";
    checkpassword.innerHTML = "";
    frmErr.innerHTML = "Please enter valid details";
    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);

    return false;
  } else {
    errMsgpassword.innerHTML = "";
    inputBorderPassword.style.borderColor = "green";
    checkpassword.innerHTML = `<i class="ri-checkbox-circle-line"></i>`;
  }

  //   for conform password
  if (validPassword != validCnPassword) {
    checkcnpassword.innerHTML = "";
    errMsgcnpassword.innerHTML = `<i class="ri-error-warning-fill"></i> Confirm password must be same as Password`;
    inputBorderCnPassword.style.borderColor = "red";
    checkcnpassword.innerHTML = "";
    frmErr.innerHTML = "Please enter valid details";
    setTimeout(() => {
      frmErr.innerHTML = "";
    }, 3000);

    return false;
  } else {
    errMsgcnpassword.innerHTML = "";
    inputBorderCnPassword.style.borderColor = "green";
    checkcnpassword.innerHTML = `<i class="ri-checkbox-circle-line"></i>`;
  }
}

// for print details




const printBtn = document.querySelector(".printBtn");
printBtn.addEventListener("click",()=>{
print();
});