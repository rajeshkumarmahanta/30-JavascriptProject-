const addBtn = document.querySelector("#addBtn");

let itemsList = document.querySelector(".items-list");
itemsList.innerHTML = "";
let TPrice = 0;
addBtn.addEventListener('click',()=>{
    // alert('hello');
    const item = document.querySelector("#item").value;
const price = document.querySelector("#price").value;
    if(item == "" || item == null || price == "" || price == null || price == NaN){
        alert("Please Add Items");
    }else{
        let Tprice = document.querySelector('.Tprice');
        TPrice = TPrice + parseInt(price);
           
            itemsList.innerHTML += `<li class="items">
            <span class="item-name">${item}</span>
            <span class="item-price">Price: ${price}/-</span>
        </li>`;
        Tprice.innerHTML = `Total price: ${TPrice}/-`;
       
    }
    item.innerHTML = "";
price.innerHTML = "";

});



