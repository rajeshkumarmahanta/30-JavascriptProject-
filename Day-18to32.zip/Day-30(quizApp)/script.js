const questions = [
  {
    question: "Which element to used to give title to a table?",
    answars: [
      { text: "Caption", correct: true },
      { text: "Headline", correct: false },
      { text: "Title", correct: false },
      { text: "Heading", correct: false },
    ],
  },
  {
    question:
      "Which of the following property is used to control the space between the border and content in a table?",
    answars: [
      { text: "border", correct: false },
      { text: "padding", correct: true },
      { text: "margin", correct: false },
      { text: "resize", correct: false },
    ],
  },
  {
    question:
      "Which of the following is used to read a HTML page and render it?",
    answars: [
      { text: "Web server", correct: false },
      { text: "Web matrix", correct: false },
      { text: "Web browser", correct: true },
      { text: "None of the mentioned", correct: false },
    ],
  },
  {
    question:
      "Which of the following programming languages is commonly used for server-side scripting in web development?",
    answars: [
      { text: "HTML", correct: false },
      { text: "Javascript", correct: false },
      { text: "Css", correct: false },
      { text: "PHP", correct: true },
    ],
  },
  {
    question:
      "What application can one create even before the introduction of HTML5?",
    answars: [
      { text: "Forms", correct: true },
      { text: "Browser based games", correct: false },
      { text: "Web applications", correct: false },
      { text: "Mobile applications", correct: false },
    ],
  },
];

const questionElement = document.querySelector(".question");
const answarButtons = document.querySelector(".quiz-answar");
const nextBtn = document.querySelector(".submit-NextBtn");

let currentQuestionIndex = 0;
let score = 0;

function startQuiz() {
  currentQuestionIndex = 0;
  score = 0;
  nextBtn.innerHTML = "Next";
  showQuestion();
}

function showQuestion() {
  resetState();
  let currentQuestion = questions[currentQuestionIndex];
  let questionNo = currentQuestionIndex + 1;
  questionElement.innerHTML = questionNo + ". " + currentQuestion.question;
  currentQuestion.answars.forEach((answar) => {
    const buttonA = document.createElement("button");
    buttonA.innerHTML = answar.text;
    // console.log(answar.text);
    buttonA.classList.add("options");
    answarButtons.appendChild(buttonA);
    if (answar.correct) {
        buttonA.dataset.correct = answar.correct;
    }
    buttonA.addEventListener("click", selectAnswar);
  });
}
startQuiz();
console.log(questions);
function resetState() {
  // console.log(answarButtons.firstChild);
  nextBtn.style.display = "none";
  while (answarButtons.firstChild) {
    answarButtons.removeChild(answarButtons.firstChild);
  }
}
function selectAnswar(e) {
  const selectedBtn = e.target;
  const isCorrect = selectedBtn.dataset.correct === "true";
  if (isCorrect) {
    selectedBtn.classList.add("correct");
    score ++;
  } else {
    selectedBtn.classList.add("incorrect");
  }
//   console.log(Array.from(answarButtons.children));
  Array.from(answarButtons.children).forEach((button) => {
    if (button.dataset.correct === "true") {
      button.classList.add("correct");
    }
    button.disabled = true;
  });
  nextBtn.style.display = "block";
};
function showScore(){
    resetState();
    questionElement.innerHTML = `You scroed ${score} out of ${questions.length}!`;
    nextBtn.innerHTML = "Play Again";
    nextBtn.style.display = "block";
}
function handleNextBtn(){
    currentQuestionIndex ++;
    if(currentQuestionIndex < questions.length){
    showQuestion();
    }else{
        showScore();
    }
};
nextBtn.addEventListener("click",()=>{
    if(currentQuestionIndex < questions.length){
        handleNextBtn();
    }else{
        startQuiz();
    }
});


