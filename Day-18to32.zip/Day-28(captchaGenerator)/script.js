
const btn = document.querySelector('#refreshBtn');
const showCaptcha = document.querySelector('#showCaptcha');

const submitBtn = document.querySelector('#submitBtn');
function GenerateCaptcha(){
    let RandomNum = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
    let captcha ="";
    for(let i=0;i<6;i++){
        captcha += RandomNum[Math.floor(Math.random()*RandomNum.length)];
    }
    // console.log(captcha);
    // console.log(RandomNum.length);
    showCaptcha.innerHTML = captcha;
};
submitBtn.addEventListener('click',()=>{
    let inputBox = document.querySelector('#inputBox').value;
    let captchmsg = document.querySelector('#captchmsg');
    if(inputBox == "" || inputBox == null){
        captchmsg.innerHTML = "Generate captcha & Enter captcha";
        captchmsg.style.color="red";
        setInterval(()=>{
            captchmsg.innerHTML = "";
        },5000);
       
      }else if(showCaptcha.innerHTML == ""){
        captchmsg.innerHTML = "Generate captcha";
        captchmsg.style.color="red";
        setInterval(()=>{
            captchmsg.innerHTML = "";
        },5000);
    }else if(inputBox !=showCaptcha.innerHTML){
        captchmsg.innerHTML = "invalid captcha";
        captchmsg.style.color="red";
        setInterval(()=>{
            captchmsg.innerHTML = "";
        },5000);
        
      }else if(inputBox == showCaptcha.innerHTML){
        captchmsg.innerHTML = "valid captcha";
        captchmsg.style.color="green";
      }
});
