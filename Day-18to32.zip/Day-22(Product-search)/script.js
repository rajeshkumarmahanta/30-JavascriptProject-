const searchInput = document.querySelector("#searchInput").value.toUpperCase();
const productList = document.querySelector(".product-list");
const Pname = productList.querySelectorAll(".p-details h4");
const api = "https://fakestoreapi.in/api/products";

window.addEventListener("load", () => {
  fetch(api)
    .then((res) => {
      return res.json();
    })
    .then((resData) => {
      //onsole.log(resData)
      const productList = document.querySelector(".product-list");
      //const Categories = document.querySelector(".Categories");
      productList.innerHTML = "";
      //   Categories.innerHTML ="";
      resData.products.forEach((items) => {
        //console.log(items);
        let title = items.title;
        let price = items.price;
        let category = items.category;
        let image = items.image;
        //console.log(image)
        productList.innerHTML += `<div class="product" data-item="${category}">
        <div class="p-det-i">
        <img src="${image}" alt="">
        <div class="p-details">
            <h4>${title.slice(0, 45)}...</h4>
            <h5>$ ${price}</h5>
        </div>
        </div>
    </div>`;
    const FilterBtn = document.querySelectorAll(".FilterBtn");
    const productsI = document.querySelectorAll(".product");
    
    FilterBtn.forEach((button) => {
      button.addEventListener("click", (e) => {
        FilterBtn.forEach((FilterBtn) => {
          FilterBtn.classList.remove("active");
        });
    
        const buttonfliter = e.target.dataset.filter;
        console.log(buttonfliter)
        productsI.forEach((prod) => {
            if(buttonfliter == "all"){
                prod.style.display = "block";
                
            }else{
                const proFilter = prod.dataset.item
                if(buttonfliter == proFilter){
                    prod.style.display = "block";
                }else{
                    prod.style.display = "none";

                }
            }
        });
    
        button.classList.add("active");
      });
    });
      });
    })
    .catch((err) => {
      console.log(err);
    });
});
const searchProduct = () => {
  //   let searchPH = document.querySelectorAll(".product .p-details h4");
  let searchP = document.querySelectorAll(".product");
  let searchInput = document.querySelector("#searchInput").value;
  //console.log(searchP.length);
  for (let i = 0; i < searchP.length; i++) {
    console.log(searchP[i]);
    let pname = searchP[i].querySelector("h4");
    console.log(pname.innerHTML.toLowerCase());
    if (!pname.innerHTML.toLowerCase().includes(searchInput.toLowerCase())) {
      searchP[i].style.display = "none";
    } else {
      searchP[i].style.display = "block";
    }
  }
};


