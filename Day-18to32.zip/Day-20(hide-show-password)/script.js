const hide_eye = document.querySelector('#hide_eye');
const pwd = document.querySelector("#pwd");
hide_eye.addEventListener("click",(e)=>{
   console.log(e.target.classList[0])
   if(e.target.classList[0] == "ri-eye-fill"){
    e.target.classList.remove("ri-eye-fill");
    e.target.classList.add("ri-eye-off-fill");
   }else{
    e.target.classList.remove("ri-eye-off-fill");
    e.target.classList.add("ri-eye-fill");
   }
    if(pwd.type == "password"){
        pwd.type = "text";
    }else{
        pwd.type = "password";
    }
});