// for samosa

const SminusBtn = document.querySelector(".Sminus");
const SplusBtn = document.querySelector(".Splus");
const ValueTextS = document.querySelector(".SamosaValue");
let Svalue = 0;
SminusBtn.addEventListener("click", () => {
    Svalue --;
    if(Svalue <=0){
        ValueTextS.innerHTML = 0;
        Svalue = 0;
    }else{
        ValueTextS.innerHTML = Svalue;
    }

});
SplusBtn.addEventListener("click", () => {
    Svalue ++;
    ValueTextS.innerHTML = Svalue;
    

});

// for kachodi
const Kachodiminus = document.querySelector(".Kachodiminus");
const Kachodiplus = document.querySelector(".Kachodiplus");
const KachodiValue = document.querySelector(".KachodiValue");
let Kachovalue = 0;
Kachodiminus.addEventListener("click", () => {
    Kachovalue --;
    if(Kachovalue <=0){
        KachodiValue.innerHTML = 0;
        Kachovalue = 0;
    }else{
        KachodiValue.innerHTML = Kachovalue;
    }

});
Kachodiplus.addEventListener("click", () => {
    Kachovalue ++;
    KachodiValue.innerHTML = Kachovalue;

});


// for Tea
const Tminus = document.querySelector(".Tminus");
const Tplus = document.querySelector(".Tplus");
const TeaValue = document.querySelector(".TeaValue");
let Tvalue = 0;
Tminus.addEventListener("click", () => {
    Tvalue --;
    if(Tvalue <=0){
        TeaValue.innerHTML = 0;
        Tvalue = 0;
    }else{
        TeaValue.innerHTML = Tvalue;
    }

});
Tplus.addEventListener("click", () => {
    Tvalue ++;
    TeaValue.innerHTML = Tvalue;

});

// fpr coffie

const CFminus = document.querySelector(".CFminus");
const CFplus = document.querySelector(".CFplus");
const CoffieValue = document.querySelector(".CoffieValue");
let COFEvalue = 0;
CFminus.addEventListener("click", () => {
    COFEvalue --;
    if(COFEvalue <=0){
        CoffieValue.innerHTML = 0;
        COFEvalue = 0;
    }else{
        CoffieValue.innerHTML = COFEvalue;
    }
});
CFplus.addEventListener("click", () => {
    COFEvalue ++;
    CoffieValue.innerHTML = COFEvalue;
});

// for ice cream
const Iceminus = document.querySelector(".Iceminus");
const Iceplus = document.querySelector(".Iceplus");
const IceValue = document.querySelector(".IceValue");
let Icecreamvalue = 0;
Iceminus.addEventListener("click", () => {
    Icecreamvalue --;
    if(Icecreamvalue <=0){
        IceValue.innerHTML = 0;
        Icecreamvalue = 0;
    }else{
        IceValue.innerHTML = Icecreamvalue;
    }

});
Iceplus.addEventListener("click", () => {
    Icecreamvalue ++;
    IceValue.innerHTML = Icecreamvalue;


});

// for bada
const Badaminus = document.querySelector(".Badaminus");
const Badaplus = document.querySelector(".Badaplus");
const BadaValue = document.querySelector(".BadaValue");
let Bavalue = 0;
Badaminus.addEventListener("click", () => {
    Bavalue --;
    if(Bavalue <=0){
        BadaValue.innerHTML = 0;
        Bavalue = 0;
    }else{
        BadaValue.innerHTML = Bavalue;
    }

});
Badaplus.addEventListener("click", () => {
    Bavalue ++;
    BadaValue.innerHTML = Bavalue;


});

// for dosa
const Dosaminus = document.querySelector(".Dosaminus");
const Dosaplus = document.querySelector(".Dosaplus");
const DosaValue = document.querySelector(".DosaValue");
let DOvalue = 0;
Dosaminus.addEventListener("click", () => {
    DOvalue --;
    if(DOvalue <=0){
        DosaValue.innerHTML = 0;
        DOvalue = 0;
    }else{
        DosaValue.innerHTML = DOvalue;
    }

});
Dosaplus.addEventListener("click", () => {
    DOvalue ++;
    DosaValue.innerHTML = DOvalue;


});

// for Biriyani
const Brnminus = document.querySelector(".Brnminus");
const Brnplus = document.querySelector(".Brnplus");
const BiriyaniValue = document.querySelector(".BiriyaniValue");
let BIRIvalue = 0;
Brnminus.addEventListener("click", () => {
    BIRIvalue --;
    if(BIRIvalue <=0){
        BiriyaniValue.innerHTML = 0;
        BIRIvalue = 0;
    }else{
        BiriyaniValue.innerHTML = BIRIvalue;
    }

});
Brnplus.addEventListener("click", () => {
    BIRIvalue ++;
    BiriyaniValue.innerHTML = BIRIvalue;


});

// for dahi pakhala

const Pkhlminus = document.querySelector(".Pkhlminus");
const Pkhlplus = document.querySelector(".Pkhlplus");
const PakhalaValue = document.querySelector(".PakhalaValue");
let Dahivalue = 0;
Pkhlminus.addEventListener("click", () => {
    Dahivalue --;
    if(Dahivalue <=0){
        PakhalaValue.innerHTML = 0;
        Dahivalue = 0;
    }else{
        PakhalaValue.innerHTML = Dahivalue;
    }

});
Pkhlplus.addEventListener("click", () => {
    Dahivalue ++;
    PakhalaValue.innerHTML = Dahivalue;


});

// Foe Rice Mill

const RiceMminus = document.querySelector(".RiceMminus");
const RiceMplus = document.querySelector(".RiceMplus");
const RiceMValue = document.querySelector(".RiceMValue");
let Rcevalue = 0;
RiceMminus.addEventListener("click", () => {
    Rcevalue --;
    if(Rcevalue <=0){
        RiceMValue.innerHTML = 0;
        Rcevalue = 0;
    }else{
        RiceMValue.innerHTML = Rcevalue;
    }

});
RiceMplus.addEventListener("click", () => {
    Rcevalue ++;
    RiceMValue.innerHTML = Rcevalue;


});

// for fish mill

const FishMminus = document.querySelector(".FishMminus");
const FishMplus = document.querySelector(".FishMplus");
const FishMValue = document.querySelector(".FishMValue");
let FShvalue = 0;
FishMminus.addEventListener("click", () => {
    FShvalue --;
    if(FShvalue <=0){
        FishMValue.innerHTML = 0;
        FShvalue = 0;
    }else{
        FishMValue.innerHTML = FShvalue;
    }

});
FishMplus.addEventListener("click", () => {
    FShvalue ++;
    FishMValue.innerHTML = FShvalue;
});

// for veg Mill

const VegMminus = document.querySelector(".VegMminus");
const VegMplus = document.querySelector(".VegMplus");
const VegMValue = document.querySelector(".VegMValue");
let VGvalue = 0;
VegMminus.addEventListener("click", () => {
    VGvalue --;
    if(VGvalue <=0){
        VegMValue.innerHTML = 0;
        VGvalue = 0;
    }else{
        VegMValue.innerHTML = VGvalue;
    }

});
VegMplus.addEventListener("click", () => {
    VGvalue ++;
    VegMValue.innerHTML = VGvalue;
});

// for chiken mill
const ChikenMminus = document.querySelector(".ChikenMminus");
const ChikenMplus = document.querySelector(".ChikenMplus");
const ChikenMValue = document.querySelector(".ChikenMValue");
let CKNvalue = 0;
ChikenMminus.addEventListener("click", () => {
    CKNvalue --;
    if(CKNvalue <=0){
        ChikenMValue.innerHTML = 0;
        CKNvalue = 0;
    }else{
        ChikenMValue.innerHTML = CKNvalue;
    }

});
ChikenMplus.addEventListener("click", () => {
    CKNvalue ++;
    ChikenMValue.innerHTML = CKNvalue;
});

// for moton mill
const MotonMminus = document.querySelector(".MotonMminus");
const MotonMplus = document.querySelector(".MotonMplus");
const MotonMValue = document.querySelector(".MotonMValue");
let MTNvalue = 0;
MotonMminus.addEventListener("click", () => {
    MTNvalue --;
    if(MTNvalue <=0){
        MotonMValue.innerHTML = 0;
        MTNvalue = 0;
    }else{
        MotonMValue.innerHTML = MTNvalue;
    }

});
MotonMplus.addEventListener("click", () => {
    MTNvalue ++;
    MotonMValue.innerHTML = MTNvalue;
    addItemToBill();

});

const inputName = document.querySelector('#inputName');
const inputEmail = document.querySelector('#inputEmail');
const inputPhone = document.querySelector('#inputPhone');

inputName.addEventListener('keyup',()=>{
    // console.log('press')
    const billName = document.querySelector('#billName');
    
   
    billName.innerHTML = inputName.value;
    
  
});
inputEmail.addEventListener('keyup',()=>{
    const billMail = document.querySelector('#billMail');
    billMail.innerHTML = inputEmail.value;
    // console.log('press')
});
inputPhone.addEventListener('keyup',()=>{
    // console.log('press')
    const billContact = document.querySelector('#billContact');
    billContact.innerHTML = inputPhone.value;
});



const billtime = document.querySelector('#billtime');
const billDate = document.querySelector('#billDate');
setInterval(()=>{
    let date = new Date();
    let h = date.getHours();
    let m = date.getMinutes();
    let s = date.getSeconds();
    let u = (h >= 12) ? 'PM' : 'AM';

    if(h > 12){
        h = h - 12;
    }
   h = ( h < 10 ) ? '0' + h : h;
   m = ( m < 10 ) ? '0' + m : m;
   s = ( s < 10 ) ? '0' + s : s;

    billtime.innerHTML = h+": " + m +": " + s +" "+ u;
    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    billDate.innerHTML = `${day.toString()}-${month.toString()}-${year.toString()}`;
    
},1000);

    let Num = '';
    let numLi = '0123456789';
    for (let i=0 ; i < 10; i++){
        Num+= numLi[Math.floor(Math.random() * 10)];
    }
    const billInvoNo = document.querySelector('#billInvoNo');
    billInvoNo.innerHTML = Num;

function addItemToBill(){
    let yourBill = document.querySelector('.your-bill');
    let Billtable = document.createElement('table');
    Billtable.classList.add('Billtable');
    yourBill.appendChild(Billtable);
    let billList = ` <tr>
    <th>Sl.No</th>
    <th>Item</th>
    <th>Price</th>
    <th>Quantity</th>
    <th>Total</th>
</tr>
<tr>
    <td>1</td>
    <td>Samosa</td>
    <td>10</td>
    <td>2</td>
    <td>10x2 = 20</td>
</tr>
`;
Billtable.innerHTML = billList;
}


