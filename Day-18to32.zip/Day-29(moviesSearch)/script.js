let moviesDetails = [
    {
        name:"Avenger's Endgame",
        desc:"After the devastating events of Avengers: Infinity War (2018), the universe is in ruins...",
        image:"image/Avengers-Endgame-2019-Dual-Audio-Hindi.jpg",
        rating:4.5,

    },{
        name:"Avenger's Infinity war",
        desc:"The Avengers and their allies must be willing to sacrifice all in an attemp...",
        image:"image/Avengers-Infinity-War-2018-Dual-Audio-Hindi-English-Movie.jpg",
        rating:4.6,
    }
    ,{
        name:"Captain America: Civil War",
        desc:"Political involvement in the Avengers' affairs causes a rift between Captain America and Iron Man....",
        image:"image/Captain-America-Civil-War-2016-Dual-Audio-Hindi-English-Movie.jpg",
        rating:4.9,
    }
    ,{
        name:"Captain Marvel",
        desc:"Carol Danvers becomes one of the universe's most powerful heroes when Earth is caught in the middle of...",
        image:"image/Captain-Marvel-2019-Dual-Audio-Hindi-English-Movie.jpg",
        rating:4.5,
    }
    ,{
        name:"Doctor Strange  in the Multiverse of Madness",
        desc:"Dr. Stephen Strange casts a forbidden spell that opens the doorway to the multiverse...",
        image:"image/Doctor-Strange-in-the-Multiverse-of-Madness-2022-English-Movie.jpg",
        rating:4.3,
    }
    ,{
        name:"Doctor Strange",
        desc:"While on a journey of physical and spiritual healing, a brilliant neurosurgeon...",
        image:"image/Doctor-Strange-2016-Dual-Audio-Hindi-English-Movie.jpg",
        rating:4.7,
    }
    ,{
        name:"I Am Groot",
        desc:"A series of shorts featuring the seedling Groot along with several new and unusual...",
        image:"image/I-Am-Groot-Season-1-English-Marvel-Studios-Short-WEB-Series.jpg",
        rating:4.8,
    }
    ,{
        name:"Iron Man 3",
        desc:"When Tony Stark's world is torn apart by a formidable terrorist called the...",
        image:"image/Iron-Man-3-2013-Dual-Audios-Hindi-English-Movie.jpg",
        rating:4.8,
    }
    ,{
        name:"Spider Man 2",
        desc:"Peter Parker is beset with troubles in his failing personal life as he battles a...",
        image:"image/Spider-Man-2-2004-Dual-Audios-Hindi-English-Movie.jpg",
        rating:4.9,
    }
    ,{
        name:"Iron Man 3",
        desc:"Earth's mightiest heroes must come together and learn to fight as a team if...",
        image:"image/The-Avengers-2012-Dual-Audio-Hindi-English-Movie.jpg",
        rating:4.8,
    }
    ,{
        name:"Thor",
        desc:"The powerful but arrogant god Thor is cast out of Asgard to live amongst...",
        image:"image/Thor-2011-Dual-Audio-Hindi-English-Movie.jpg",
        rating:4.9,
    }
    ,{
        name:"Thor Ragnarok",
        desc:"Imprisoned on the planet Sakaar, Thor must race against time to return...",
        image:"image/Thor-Ragnarok-2017-Hindi-English.jpg",
        rating:4.4,
    }
    ,{
        name:"Thor Love And Thunder",
        desc:"Thor enlists the help of Valkyrie, Korg and ex-girlfriend Jane Foster to fight Gorr the...",
        image:"image/Thor-Love-and-Thunder-2022.jpg",
        rating:4.4,
    }
    ,{
        name:"Thor The Dark World",
        desc:"When the Dark Elves attempt to plunge the universe into darkness, Thor must embark...",
        image:"image/Thor-The-Dark-World-2013.jpg",
        rating:4.9,
    }

];

let searchbtn = document.querySelector("#searchbtn");
function movies(){
const cardMainContainer =document.querySelector(".cardMainContainer");
cardMainContainer.innerHTML = "";
moviesDetails.forEach((movies)=>{
    cardMainContainer.innerHTML += `
    <div class="card m-3" style="width: 18rem;height: 29rem;">
        <div class="cardImgDiv">
            <img src="${movies.image}" height="300px" class="card-img-top"
                alt="...">
        </div>
        <div class="card-body">
            <h5 class="card-title fw-bold">${movies.name}</h5>
            <p class="mb-2">Rating: ${movies.rating}</p>
            <a href="#" class="card-text link-dark text-decoration-none">${movies.desc}</a>

        </div>
    </div>`;

});


};

searchbtn.addEventListener('click',movieSearch=()=>{
    let card = document.querySelectorAll('.card');
    let searchResult = document.querySelector('#searchResult');
    let input = document.querySelector("#MoviesSearch").value.toLowerCase();
    // console.log(card);
    searchResult.innerHTML = input.toUpperCase();
    for(let i = 0; i < card.length; i++) {
        let Mname = card[i].querySelector('h5').innerHTML.toLowerCase();
        // console.log(card[i].querySelector('h5').innerHTML.toLowerCase());
       if(Mname.includes(input)){
        card[i].style.display="block";
       }else{
        card[i].style.display="none";
      
       }

        
    }
});
let inputbox = document.querySelector("#MoviesSearch");
inputbox.addEventListener('keyup',movieSearch)
window.addEventListener('load',movies);


