const calcBtn = document.querySelector("#calcBtn");
const calculate = () => {
  const mil = document.querySelector("#MIL").value;
  const eng = document.querySelector("#ENG").value;
  const math = document.querySelector("#MATH").value;
  const phy = document.querySelector("#PHY").value;
  const CHE = document.querySelector("#CHE").value;
  const it = document.querySelector("#IT").value;

  if (mil == "" || mil == null) {
    alert("Enter MIL mark");
    return false;
  } else if (isNaN(mil)) {
    alert("Enter number only");
    return false;
  } else if (parseInt(mil) > 100) {
    alert("Number Must be less than 100");
    return false;
  } else if (eng == "" || eng == null) {
    alert("Enter ENG mark");
    return false;
  } else if (isNaN(eng)) {
    alert("Enter number only");
    return false;
  } else if (parseInt(eng) > 100) {
    alert("Number Must be less than 100");
    return false;
  } else if (math == "" || math == null) {
    alert("Enter MATH mark");
    return false;
  } else if (isNaN(math)) {
    alert("Enter number only");
    return false;
  } else if (parseInt(math) > 100) {
    alert("Number Must be less than 100");
    return false;
  } else if (phy == "" || phy == null) {
    alert("Enter PHY mark");
    return false;
  } else if (isNaN(phy)) {
    alert("Enter number only");
    return false;
  } else if (parseInt(phy) > 100) {
    alert("Number Must be less than 100");
    return false;
  } else if (CHE == "" || CHE == null) {
    alert("Enter CHE mark");
    return false;
  } else if (isNaN(CHE)) {
    alert("Enter number only");
    return false;
  } else if (parseInt(CHE) > 100) {
    alert("Number Must be less than 100");
    return false;
  } else if (it == "" || it == null) {
    alert("Enter IT mark");
    return false;
  } else if (isNaN(it)) {
    alert("Enter number only");
    return false;
  } else if (parseInt(it) > 100) {
    alert("Number Must be less than 100");
    return false;
  }
  let ObtainedMark =
    parseInt(mil) +
    parseInt(math) +
    parseInt(eng) +
    parseInt(phy) +
    parseInt(CHE) +
    parseInt(it);
  // console.log(ObtainedMark);
  let obtmark = document.querySelector(".obtinedmark");
  obtmark.innerHTML = ObtainedMark;
  let totalMark = 600;
  let percentage = (ObtainedMark / totalMark) * 100;
  console.log(percentage);
  let percent = document.querySelector(".percent");
  percent.innerHTML = `${Math.floor(percentage)} %`;

  //  if(percentage >= 91){
  //    console.log("true");
  //  }else{
  //    console.log("false");
  //  }
  let grade = document.querySelector(".grade");
  let remark = document.querySelector(".remark");
  if (percentage >= 91) {
    //console.log("A1");
    grade.innerHTML = "A1";
    remark.innerHTML = "Pass";
    remark.style.color = "green";
    //console.log("pass");
  } else if (percentage >= 81) {
    //console.log("A2");
    //console.log("pass");
    grade.innerHTML = "A2";
    remark.innerHTML = "Pass";
    remark.style.color = "green";
  } else if (percentage >= 71) {
    //console.log("B1");
    //console.log("pass");
    grade.innerHTML = "B1";
    remark.innerHTML = "Pass";
    remark.style.color = "green";
  } else if (percentage >= 61) {
    //console.log("B2");
    //console.log("pass");
    grade.innerHTML = "B2";
    remark.innerHTML = "Pass";
    remark.style.color = "green";
  } else if (percentage >= 51) {
    grade.innerHTML = "C1";
    remark.innerHTML = "Pass";
    remark.style.color = "green";
    //console.log("C1");
    //console.log("pass");
  } else if (percentage >= 41) {
    //  console.log("C2");
    //  console.log("pass");
    grade.innerHTML = "C2";
    remark.innerHTML = "Pass";
    remark.style.color = "green";
  } else if (percentage >= 33) {
    //  console.log("D");
    //  console.log("pass");
    grade.innerHTML = "D";
    remark.innerHTML = "Pass";
    remark.style.color = "green";
  } else if (percentage >= 21) {
    //  console.log("E1");
    //  console.log("fail");
    grade.innerHTML = "E1";
    remark.innerHTML = "fail";
    remark.style.color = "red";
  } else if (percentage >= 0) {
    grade.innerHTML = "E2";
    remark.innerHTML = "fail";
    remark.style.color = "red";
  }
};
// calcBtn.addEventListener('click',calculate());
const clear = document.getElementById("clear");
clear.addEventListener("click", () => {
  document.querySelector("#MIL").value='';
  document.querySelector("#ENG").value='';
  document.querySelector("#MATH").value='';
  document.querySelector("#PHY").value='';
  document.querySelector("#CHE").value='';
  document.querySelector("#IT").value='';
 
});
