const drag = document.querySelector('#carImg');
const drop = document.querySelector('.drop');
const returnDrag = document.querySelector('.drag-img');
drag.addEventListener('dragstart',(e)=>{
e.dataTransfer.setData('text/html',e.target.id);

});
drop.addEventListener('dragover',(e)=>{
e.preventDefault();

});
drop.addEventListener('drop',(e)=>{
e.preventDefault();
let data = e.dataTransfer.getData("text/html");
e.target.appendChild(document.getElementById(data));
});
drag.addEventListener('dragstart',(e)=>{
  e.dataTransfer.setData('text/html',e.target.id);
  
  })
  returnDrag.addEventListener('drop',(e)=>{
  e.preventDefault();
  let data = e.dataTransfer.getData("text/html");
  e.target.appendChild(document.getElementById(data));
  
  
  });
  returnDrag.addEventListener('dragover',(e)=>{
  e.preventDefault();
  });