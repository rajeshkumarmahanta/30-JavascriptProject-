// const removeBackground = async (base64Image) => {
//     const options = {
//       method: "POST",
//       headers: {
//         "x-api-key": bbf2b4b2cb0a7d6c0727fcbd9d30552e8830c94b,
//         "Content-Type": "application/json",
//         Accept: "application/json",
//       },
//       body: JSON.stringify({
//         image_file_b64: base64Image.split(",")[1],
//       }),
//     };

//     fetch("https://sdk.photoroom.com/v1/segment", options)
//       .then((response) => response.json())
//       .then((response) => {
//         console.log(response);
//       })
//       .catch((err) => console.error(err));
//   };

const uploadBtn = document.querySelector("#uploadBtn");
uploadBtn.addEventListener("click", () => {
  const Fileinput = document.querySelector("#filePicker");
  const image = Fileinput.files[0];
  const formData = new FormData();
  formData.append("image_file", image);
  formData.append("size", "auto");
  const api_keys = "Lgz2W2ht7EUk2W5Zj8XEupYq";
  fetch("https://api.remove.bg/v1.0/removebg", {
    method: "POST",
    headers: {
      "X-Api-Key": api_keys,
    },
    body: formData,
  })
    .then((response) => {
      console.log(response);
      return response.blob();
    })
    .then((finalRsponse) => {
    //   console.log(finalRsponse);
    //   console.log(finalRsponse.type);
      const imgUrl = URL.createObjectURL(finalRsponse);
    //   console.log(imgUrl);
      const img = document.querySelector("#img");
      img.src = imgUrl;
   
    })
    .catch();
});
