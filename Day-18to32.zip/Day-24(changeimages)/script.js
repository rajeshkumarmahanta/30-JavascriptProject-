const tabbtns = document.querySelectorAll('#tabBtns')
const content = document.querySelectorAll('.content');
tabbtns.forEach((button,index)=>{
    button.addEventListener('click',()=>{
        content.forEach((cont)=>{
            cont.classList.remove('active');
        })
        tabbtns.forEach((Btn)=>{
            Btn.classList.remove('active');
        });
        tabbtns[index].classList.add('active');
        content[index].classList.add('active');
        console.log(button[index])
    });
});

const carBtns = document.querySelectorAll(".Carimg")
const bikeImg = document.querySelectorAll(".bikeImg");
carBtns.forEach((carbtn)=>{
    carbtn.addEventListener('click',(e)=>{
        //console.log(e.target.id);
        let mainimg = document.querySelector("#mainchangeCar");
        if(e.target.id == "AltoGrey"){
            
            mainimg.src = "images/alto/altok10metallicgranitegrey.jpeg";

        }else if(e.target.id == "AltoSilver"){
            mainimg.src = "images/alto/altok10metallicsilkysilver.jpeg";
        }else if(e.target.id == "AltoRed"){
            mainimg.src = "images/alto/altok10metallicsizzlingred.jpeg";
        }
        else if(e.target.id == "AltoSpeedBlue"){
            mainimg.src = "images/alto/altok10metallicspeedyblue.jpeg";
        }
        else if(e.target.id == "AltoNightBlack"){
            mainimg.src = "images/alto/altok10pearlmidnightblack.png";
        }
        else if(e.target.id == "AltoGold"){
            mainimg.src = "images/alto/altok10premiumearthgold.jpeg";
        }
        else if(e.target.id == "AltoWhite"){
            mainimg.src = "images/alto/altok10solidwhite.jpeg";
        }else{
            mainimg.src = "images/alto/altok10metallicgranitegrey.jpeg";
        }
    });
});
bikeImg.forEach((bikeBtn)=>{
    bikeBtn.addEventListener('click',(e)=>{
        let mainimg = document.querySelector("#mainchangeBike");
        if(e.target.id == "dapperG"){
            mainimg.src = "images/Bullet/royal-enfield-select-model-dapper-g.jpg";
        }else if(e.target.id == "dapperGrey"){
            mainimg.src = "images/Bullet/royal-enfield-select-model-dapper-grey.jpg";
        }else if(e.target.id == "dapperO"){
            mainimg.src = "images/Bullet/royal-enfield-select-model-dapper-o.jpg";
        }
        else if(e.target.id == "dapperWhite"){
            mainimg.src = "images/Bullet/royal-enfield-select-model-dapper-white.jpg";
        }
        else if(e.target.id == "factoryBlack"){
            mainimg.src = "images/Bullet/royal-enfield-select-model-factory-black.jpg";
        }
        else if(e.target.id == "factorySilver"){
            mainimg.src = "images/Bullet/royal-enfield-select-model-factory-silver.jpg";
        }
        else if(e.target.id == "rebelBlue"){
            mainimg.src = "images/Bullet/royal-enfield-select-model-rebel-blue.jpg";
        }else if(e.target.id == "rebelBlack"){
            mainimg.src = "images/Bullet/royal-enfield-select-model-rebel-black.jpg";
        }else if(e.target.id == "rebelRed"){
            mainimg.src = "images/Bullet/royal-enfield-select-model-rebel-red.jpg";
        }else{
            mainimg.src = "images/Bullet/royal-enfield-select-model-dapper-ash.jpg";
        }
    });
});