const pause = document.querySelector('.pause');
const pauseicon = document.querySelector('.fa-circle-play');
const prev = document.querySelector('.prev');
const next = document.querySelector('.next');
const audio = document.getElementById('audio');
const image = document.querySelector('.music-img');
const artist = document.querySelector('.artist');
const titlename = document.querySelector('.title-name');
/* <i class="fa-solid fa-circle-pause"></i> */

const songs = [
    {
        title: "Gulabi-Sadi",
        artist : "Sanju, G-Spark",
        songSource : "audio/Gulabi-Sadi(PaglaSongs).mp3",
        image : "image/19136_4.jpg"

    },{
        title: "Pushpa Pushpa",
        artist : "Allu Arjun",
        songSource : "audio/Pushpa-Pushpa(PaglaSongs).mp3",
        image : "image/20064_4.jpg" 
    },{
        title: "Tere Mote Mote Nain",
        artist : "Lokesh Gurjar, Totaram Sondhiya",
        songSource : "audio/Tere-Mote-Mote-Nain(PaglaSongs).mp3",
        image : "image/19991_4.jpg"
    }
];

let isplaying = true;
function playMusic(){
    // alert("play")
    // alert("hello");
    isplaying = false;
    audio.play();
    pauseicon.classList.replace('fa-circle-play','fa-circle-pause');
    image.classList.add("animation");
};
function resumeMusic() {
    // alert("resume")
    // alert("hello");
    isplaying = true;
    audio.pause();
    pauseicon.classList.replace('fa-circle-pause','fa-circle-play');
    image.classList.remove("animation");
};
pause.addEventListener('click',()=>{

    if(isplaying){
        playMusic();
    }else{
        resumeMusic(); 
    }
});



function loadSongs(songs){
    artist.innerHTML = songs.artist;
    titlename.innerHTML = songs.title;
    audio.src = songs.songSource;
    image.src = songs.image;
    // console.log(songs.artist);
    // console.log(songs.title);
    // console.log(songs.songSource);
    // console.log(songs.image);
};
const progressbar = document.querySelector(".progress");
const progressDiv = document.querySelector(".progress-div");
let AcurrentTime = document.querySelector(".current-time");
let Aduration = document.querySelector(".duration");
audio.addEventListener('timeupdate',(ev)=>{
// console.log(ev);

const {currentTime,duration} = ev.srcElement;
// console.log(currentTime);
// console.log(duration);
let progressTime = (currentTime / duration) * 100;

progressbar.style.width=progressTime +"%";
// duration.innerHTML = `${duration/60}`;
let minDuration = Math.floor(duration / 60);
let secDuration = Math.floor(duration % 60);
// console.log(Aduration);
if(duration){
    Aduration.innerHTML = minDuration + ":" + secDuration;
}
let AcurrentTimeMin = Math.floor(currentTime / 60);
let AcurrentTimeSec = Math.floor(currentTime % 60);
// console.log(Aduration);

if(AcurrentTimeSec < 10){
    AcurrentTimeSec = "0" + AcurrentTimeSec ;
}
AcurrentTime.innerHTML = AcurrentTimeMin + ":" + AcurrentTimeSec;

});

let songIndex = 0;
audio.addEventListener("ended",()=>{
    songIndex = (songIndex + 1) % songs.length;
    loadSongs(songs[songIndex]);
    playMusic();
});
next.addEventListener('click',()=>{
    songIndex = (songIndex + 1) % songs.length;
    loadSongs(songs[songIndex]);
    playMusic();
});
prev.addEventListener('click',()=>{
    songIndex = (songIndex - 1 + songs.length) % songs.length;
    loadSongs(songs[songIndex]);
    playMusic();
});

progressDiv.addEventListener('click',(evnt)=>{
const {duration} = audio;
let moveProgress = (evnt.offsetX / evnt.srcElement.clientWidth) * duration;
audio.currentTime = moveProgress;
});